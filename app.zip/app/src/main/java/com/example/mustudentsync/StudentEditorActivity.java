
package com.example.mustudentsync;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.mustudentsync.data.SyncManager;
import com.example.mustudentsync.model.StudentEntity;
import com.example.mustudentsync.viewmodel.StudentEditorViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class StudentEditorActivity extends AppCompatActivity {

    private TextInputLayout tilEditorName;
    private TextInputLayout tilEditorNumber;
    private TextInputLayout tilEditorProgram;

    private TextInputEditText etEditorName;
    private TextInputEditText etEditorNumber;

    private AutoCompleteTextView actvEditorProgram;
    private Spinner spnEditorGroup;

    private TextView tvGroupFullIndicator;

    private MaterialButton btnEditorSave;
    private MaterialButton btnEditorCancel;

    private static final String[] GROUPS = {
            "Unassigned", "G01", "G02", "G03", "G04"
    };

    private StudentEditorViewModel viewModel;

    // Null means this screen is creating a new student.
    // Non-null means an existing student is being edited.
    private StudentEntity editing;

    private boolean isSaving = false;
    private boolean groupCheckPending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_editor);

        viewModel = new ViewModelProvider(this)
                .get(StudentEditorViewModel.class);

        initViews();
        setupDropdowns();
        setupListeners();
        loadStudentIfEditing();
    }

    private void initViews() {
        tilEditorName = findViewById(R.id.tilEditorName);
        tilEditorNumber = findViewById(R.id.tilEditorNumber);
        tilEditorProgram = findViewById(R.id.tilEditorProgram);

        etEditorName = findViewById(R.id.etEditorName);
        etEditorNumber = findViewById(R.id.etEditorNumber);

        actvEditorProgram = findViewById(R.id.actvEditorProgram);
        spnEditorGroup = findViewById(R.id.spnEditorGroup);

        tvGroupFullIndicator =
                findViewById(R.id.tvGroupFullIndicator);

        btnEditorSave = findViewById(R.id.btnEditorSave);
        btnEditorCancel = findViewById(R.id.btnEditorCancel);
    }

    private void setupDropdowns() {
        ProgramDropdownAdapter programAdapter =
                ProgramDropdownAdapter.create(this);

        actvEditorProgram.setAdapter(programAdapter);

        actvEditorProgram.setOnItemClickListener(
                (parent, view, position, id) -> {
                    if (!programAdapter.isEnabled(position)) {
                        actvEditorProgram.setText("", false);
                    }
                }
        );

        ArrayAdapter<String> groupAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                GROUPS
        );

        groupAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spnEditorGroup.setAdapter(groupAdapter);

        // IMPORTANT:
        // Changing or initializing the group selection must NEVER
        // create or update a student.
        spnEditorGroup.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        tvGroupFullIndicator.setVisibility(View.GONE);
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                }
        );
    }

    private void setupListeners() {
        btnEditorCancel.setOnClickListener(v -> finish());

        btnEditorSave.setOnClickListener(v -> validateThenSave());
    }

    private void loadStudentIfEditing() {
        String editId = getIntent().getStringExtra("STUDENT_ID");

        boolean editMode = getIntent().getBooleanExtra(
                "IS_EDIT_MODE", false
        );

        if (!editMode || editId == null || editId.trim().isEmpty()) {
            return;
        }

        viewModel.getStudent(editId).observe(this, student -> {
            if (student == null || isFinishing()) {
                return;
            }

            editing = student;

            etEditorName.setText(student.fullName);
            etEditorNumber.setText(student.studentNumber);

            actvEditorProgram.setText(student.program, false);

            for (int i = 0; i < GROUPS.length; i++) {
                if (GROUPS[i].equals(student.labGroup)) {
                    spnEditorGroup.setSelection(i);
                    break;
                }
            }
        });
    }

    private void validateThenSave() {
        if (isSaving || groupCheckPending) {
            return;
        }

        String name = etEditorName.getText() != null
                ? etEditorName.getText().toString().trim()
                : "";

        String number = etEditorNumber.getText() != null
                ? etEditorNumber.getText().toString().trim()
                : "";

        String program = actvEditorProgram.getText() != null
                ? actvEditorProgram.getText().toString().trim()
                : "";

        Object selectedItem = spnEditorGroup.getSelectedItem();

        String group = selectedItem != null
                ? selectedItem.toString()
                : "";

        clearValidationErrors();

        boolean valid = true;

        if (TextUtils.isEmpty(name)) {
            tilEditorName.setError(
                    getString(R.string.err_name_empty)
            );
            valid = false;
        }

        if (TextUtils.isEmpty(number) || number.length() != 9) {
            tilEditorNumber.setError(
                    getString(R.string.err_student_number_invalid)
            );
            valid = false;
        }

        if (TextUtils.isEmpty(program)) {
            tilEditorProgram.setError(
                    getString(R.string.err_program_unselected)
            );
            valid = false;
        }

        if (TextUtils.isEmpty(group)) {
            Toast.makeText(
                    this,
                    "Please select a lab group.",
                    Toast.LENGTH_SHORT
            ).show();
            valid = false;
        }

        if (!valid) {
            return;
        }

        // An unchanged group does not need a new capacity check.
        // This also allows editing other details of a student
        // whose current group is already full.
        if (editing != null && group.equals(editing.labGroup)) {
            saveStudent(name, number, program, group);
            return;
        }

        // Check capacity only when the user actually presses Save.
        groupCheckPending = true;
        btnEditorSave.setEnabled(false);

        viewModel.isGroupFull(group, isFull -> {
            groupCheckPending = false;

            if (isFinishing() || isDestroyed()) {
                return;
            }

            if (isFull) {
                tvGroupFullIndicator.setVisibility(View.VISIBLE);
                btnEditorSave.setEnabled(true);

                Toast.makeText(
                        StudentEditorActivity.this,
                        "This group is full. Please choose another group.",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            tvGroupFullIndicator.setVisibility(View.GONE);

            saveStudent(name, number, program, group);
        });
    }

    private void saveStudent(
            String name,
            String number,
            String program,
            String group) {

        if (isSaving) {
            return;
        }

        isSaving = true;
        btnEditorSave.setEnabled(false);

        SyncManager sync = new SyncManager(this);

        SyncManager.Callback callback = (success, message) -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }

            if (success) {
                Toast.makeText(
                        StudentEditorActivity.this,
                        editing == null
                                ? "Student created successfully."
                                : "Student updated successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                finish();
            } else {
                isSaving = false;
                btnEditorSave.setEnabled(true);

                Toast.makeText(
                        StudentEditorActivity.this,
                        message != null
                                ? message
                                : "Save failed. Please try again.",
                        Toast.LENGTH_LONG
                ).show();
            }
        };

        // Only create a student when no existing student is loaded.
        // Otherwise, update the existing student.
        if (editing == null) {
            sync.createStudent(name, number, program, group, callback);
        } else {
            sync.updateStudent(
                    editing,
                    name,
                    number,
                    program,
                    group,
                    callback
            );
        }
    }

    private void clearValidationErrors() {
        tilEditorName.setError(null);
        tilEditorNumber.setError(null);
        tilEditorProgram.setError(null);

        tvGroupFullIndicator.setVisibility(View.GONE);
    }
}
